#include<iostream>
#include<string>
using namespace std;
int dfa = 1;
void state1(char c)
{
	if (c == '!') {
		dfa = 2;
	}
	else if (c == 'a') {
		dfa = 7;
	}
	else if (c == 'p') {
		dfa = 17;
	}
	else if (c == 'A') {
		dfa = 23;
	}
	else if (c == 'n') {
		dfa = 7;
	}
	else {
		dfa = 47;
	}
}
void state2(char c)
{
	if (c == '!') {
		dfa = 3;
	}
	else if (c == '^') {
		dfa = 5;
	}
	else {
		dfa = 47;
	}
}
void state3(char c)
{
	if (cin.get()) {
		dfa = 4;
	}
	else {
		dfa = 3;
	}
}
void state4(char c)
{
	if (c == '!') {
		dfa = 2;
	}
	else {
		dfa = 47;
	}
}
void state5(char c)
{
	if (c == '^') {
		dfa = 6;
	}
	else {
		dfa = 5;
	}
}
void state6(char c)
{

	if (c == '!') {
		dfa = 4;
	}
	else {
		dfa = 47;
	}
}
void state7(char c)
{
	if (c == 'p') {
		dfa = 8;
	}
	else {
		dfa = 47;
	}
}
void state8(char c)
{
    if (c == 'p') {
		dfa = 9;
	}
	else {
		dfa = 47;
	}
}

void state9(char c)
{
	if (c == 'e') {
		dfa = 10;
	}
	else {
		dfa = 47;
	}
}

void state10(char c)
{
	if (c == 'a') {
	dfa = 11;
	}
	else {
		dfa = 47;
	}
}
void state11(char c)
{
	if (c == 'r') {
		dfa = 12;
	}
	else {
		dfa = 47;
	}
}
void state12(char c)
{
	if (c == '#') {
		dfa = 13;
	}
	else {
		dfa = 47;
	}
}
void state13(char c)
{
	if (c == '^') {
		dfa = 14;
	}
	else {
		dfa = 47;
	}
}
void state14(char c)
{
	if (c == '^') {
		dfa = 15;
	}
	else {
		dfa = 14;
	}
}
void state15(char c)
{
	if (c == ';') {
		dfa = 16;
	}
	else {
		dfa = 47;
	}
}
void state16(char c)
{
	if (c == ';') {
		dfa = 16;
	}
	else {
		dfa = 47;
	}
}
void state17(char c)
{
	if (c == 'u') {
		dfa = 18;
	}
	else {
		dfa = 47;
	}
}
void state18(char c)
{
	if (c == 't') {
		dfa = 19;
	}
	else {
		dfa = 47;
	}
}
void state19(char c)
{
	if (c == '#') {
		dfa = 20;
	}
	else {
		dfa = 47;
	}
}
void state20(char c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c == '_')) {
		dfa = 21;
	}
	else {
		dfa = 47;
	}
}
void state21(char c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c == '_') || (c>=0 && c<=9)) {
		dfa = 21;
	}
	else if (c == ';') {
		dfa = 22;
	}
	else {
		dfa = 47;
	}
}

void state22(char c)
{
	if (c == ';') {
		dfa = 22;
	}
	else {
		dfa = 47;
	}
}

void state23(char c)
{
	if (c == 'g') {
		dfa = 24;
	}
	else {
		dfa = 47;
	}
}
void state24(char c)
{
	if (c == 'r') {
		dfa = 25;
	}
	else {
		dfa = 47;
	}
}
void state25(char c)
{
	if (c == '<') {
		dfa = 26;
	}
	else {
		dfa = 47;
	}
}
void state26(char c)
{
	if (c>=0 && c<=9) {
		dfa = 27;
	}
	else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c == '_')) {
		dfa = 28;
	}
	else {
		dfa = 47;
	}
}
void state27(char c)
{
	if ((c == '<') || (c == '>') || (c == '==') || (c == '>=') || (c == '<=') || (c == '!=')) {
		dfa = 26;
	}
	else if (c>=0 && c<=9){
		dfa = 27;
	}
	else if (c == '>'){
		dfa=30;
	}
	else {
		dfa = 47;
	}
}
void state28(char c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c == '_') || (c>=0 && c<=9)) {
		dfa = 28;
	}
	else if (c == '>'){
		dfa=30;
	}
	else {
		dfa = 47;
	}
}

void state30(char c)
{
	if (c == '[') {
		dfa = 31;
	}
	else {
		dfa = 47;
	}
}
void state31(char c)
{
	if (c == ']') {
		dfa = 2;
	}
	else {
		dfa = 47;
	}
}
void state32(char c)
{
	if (c == 'y') {
		dfa = 33;
	}
	else {
		dfa = 47;
	}
}
void state33(char c)
{
	if (c == 'a') {
		dfa = 34;
	}
	else {
		dfa = 47;
	}
}
void state34(char c)
{
	if (c == '[') {
		dfa = 31;
	}
	else if (isspace(c)) {
		dfa = 35;
	}
	else {
		dfa = 47;
	}
}
void state35(char c)
{
	if (c == 'A') {
		dfa = 23;
	}
	else {
		dfa = 47;
	}
}

void state38(char c)
{
	if (c == 'u') {
		dfa = 39;
	}
	else {
		dfa = 47;
	}
}
void state39(char c)
{
	if (c == 'm') {
		dfa = 40;
	}
	else {
		dfa = 47;
	}
}
void state40(char c)
{
	if (isspace(c)) {
		dfa = 41;
	}
	else {
		dfa = 47;
	}
}
void state41(char c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c == '_')) {
		dfa = 42;
	}
	else {
		dfa = 47;
	}
}
void state42(char c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c == '_') || (c>=0 && c<=9)) {
		dfa = 42;
	}
	else if (c == ';') {
		dfa = 43;
	}
	else if(c == '='){
		dfa = 44;
	}
	else {
		dfa = 47;
	}
}
void state43(char c)
{
	if (c == ';') {
		dfa = 43;
	}
	else {
		dfa = 47;
	}
}
void state44(char c)
{
	if (c>=0 && c<=9) {
		dfa = 45;
	}
	else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c == '_')) {
		dfa = 46;
	}
	else {
		dfa = 47;
	}
}
void state45(char c)
{
	if (c>=0 && c<=9) {
		dfa = 45;
	}
	else if (c == ';') {
		dfa = 43;
	}
	else {
		dfa = 47;
	}
}
void state46(char c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c == '_') || (c>=0 && c<=9)) {
		dfa = 43;
	}
	else if (c == ';') {
		dfa = 43;
	}
	else {
		dfa = 47;
	}
}
void state47(char c)
{
	dfa = -1;
}







int isAccepted(string str)
{
	int i = 0;
	while(str[i] != '/0'){
	
	int len = str.length();
	cout << len;
	for (int i = 0; i < len; i++) {
		if (dfa == 1)
			state1(str[i]);

		else if (dfa == 2)
			state2(str[i]);

		else if (dfa == 3)
			state3(str[i]);

		else if (dfa == 4)
			state4(str[i]);

		else if (dfa == 5)
			state5(str[i]);

		else if (dfa == 6)
			state6(str[i]);

		else if (dfa == 7)
			state7(str[i]);

		else if (dfa == 8)
			state8(str[i]);

		else if (dfa == 9)
			state9(str[i]);

		else if (dfa == 10)
			state10(str[i]);

		else if (dfa == 11)
			state11(str[i]);
		else if (dfa == 11)
			state1(str[i]);

		else if (dfa == 12)
			state2(str[i]);

		else if (dfa == 13)
			state3(str[i]);

		else if (dfa == 14)
			state4(str[i]);

		else if (dfa == 15)
			state5(str[i]);

		else if (dfa == 16)
			state6(str[i]);

		else if (dfa == 17)
			state7(str[i]);

		else if (dfa == 18)
			state8(str[i]);

		else if (dfa == 19)
			state9(str[i]);

		else if (dfa == 20)
			state10(str[i]);

		else if (dfa == 21)
			state11(str[i]);
				
		else if (dfa == 22)
			state1(str[i]);

		else if (dfa == 23)
			state2(str[i]);

		else if (dfa == 24)
			state3(str[i]);

		else if (dfa == 25)
			state4(str[i]);

		else if (dfa == 26)
			state5(str[i]);

		else if (dfa == 27)
			state6(str[i]);

		else if (dfa == 28)
			state7(str[i]);

		else if (dfa == 29)
			state8(str[i]);

		else if (dfa == 30)
			state9(str[i]);

		else if (dfa == 31)
			state10(str[i]);

		else if (dfa == 32)
			state11(str[i]);
				
		else if (dfa == 33)
			state1(str[i]);

		else if (dfa == 34)
			state2(str[i]);

		else if (dfa == 35)
			state3(str[i]);

		else if (dfa == 35)
			state4(str[i]);

		else if (dfa == 36)
			state5(str[i]);

		else if (dfa == 37)
			state6(str[i]);

		else if (dfa == 38)
			state7(str[i]);

		else if (dfa == 39)
			state8(str[i]);

		else if (dfa == 40)
			state9(str[i]);

		else if (dfa == 41)
			state10(str[i]);

		else if (dfa == 42)
			state11(str[i]);	
			
		else if (dfa == 43)
			state1(str[i]);

		else if (dfa == 44)
			state2(str[i]);

		else if (dfa == 45)
			state3(str[i]);

		else if (dfa == 46)
			state4(str[i]);

		else if (dfa == 47)
			state5(str[i]);

		else
			return 0;

	}

	if ((dfa == 4) || (dfa==16) || (dfa == 22) || (dfa == 32) || (dfa == 43) )
		return 1;
	else
		return 0;

}
}
int main()
{
	string str;
	while (str != "T") {

		cout << "Enter T to terminate\nEnter the string: ";
		cin >> str;
		if (isAccepted(str))
			cout << "\tACCEPTED\n\n\n";
		else
			cout << "\tNOT ACCEPTED\n\n\n";
		dfa = 1;
	}
	return 0;
}
