package finalprojecticecreamshop;


public class Chocolate extends Flavour
{
private String clour;
 private float fat;

    public Chocolate()
    {
        
    }

    public Chocolate(String clour, float fat) 
    {
        this.clour = clour;
        this.fat = fat;
    }

    public String getClour() {
        return clour;
    }

    public void setClour(String clour) {
        this.clour = clour;
    }

    public float getFat() {
        return fat;
    }

    public void setFat(float fat) {
        this.fat = fat;
    }
 
 
 
@Override
 public void display()
   {
   System.out.print("Flavour's colour is :"+clour+"\nFlavour's fat is "+fat+"\n");

   }
 
    
}
