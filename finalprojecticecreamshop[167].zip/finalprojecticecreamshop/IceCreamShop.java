package finalprojecticecreamshop;

import java.util.ArrayList;
import java.util.Scanner;

public class IceCreamShop 
{
private String Name,Location;
private Ingredients ing; 
private Flavour fla;
private Category cat;
private ArrayList<Worker> w;
private int Choice2;
private int Choice;
private Customer co;

  
  
    public IceCreamShop()
    {
        ing=new Ingredients();
        fla=new Flavour();
        cat=new Category();
        w=new ArrayList<Worker>();
        co=new Customer();
    }

    public IceCreamShop(String Name, String Location) 
    {
        this.Name = Name;
        this.Location = Location;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public Ingredients getIng() {
        return ing;
    }

    public void setIng(Ingredients ing) {
        this.ing = ing;
    }

    public Flavour getFla() {
        return fla;
    }

    public void setFla(Flavour fla) {
        this.fla = fla;
    }

    public Category getCat() {
        return cat;
    }

    public void setCat(Category cat) {
        this.cat = cat;
    }

    public ArrayList<Worker> getW() {
        return w;
    }

    public void setW(ArrayList<Worker> w) {
        this.w = w;
    }



public void addIngredients(Ingredients i3)
{
 this.ing=i3;
}
     
 public void addFlavour(Flavour fp)
 {
  fla=fp;
 }   
 
  public void addCategory(Category ct)
  {
   cat=ct;
  }        
 
  public void addWorker(Worker wr)
   {
    w.add(wr);
   }
  
  public void workerdetail()
  {
  
      
  }
  
  
  public void Customer()
  {
  co.setName();
  }
  
  public void OrderDetail()
  {
      System.out.println("\n\nOrder List\n");
      co.display();
      System.out.println(ing.toString());
      {
      if (Choice<2)
      {
      System.out.println("\nYou Selected Strwaberry Flavour\n");
      }
      else if(Choice<3)
      {
      System.out.println("\nYou Selected Chocolate Flavour\n");
      }
      else if(Choice<4)
      {
      System.out.println("\nYou Selected Vanilla Flavour\n");
      }
      else if(Choice<5)
      {
      System.out.println("\nYou Selected Coffee Flavour\n");
      }
      else if(Choice<6)
      {
      System.out.println("\nYou Selected Cherry Flavour\n");
      }
      else
      {
      
      }
      }
  
      {
          switch(Choice2)
        {
            case 1:
            {
                System.out.println("\nYou Selected IceCream Category\n");
                break;
            }
            case 2:
            {
                System.out.println("\nYou Selected Gelato Category\n");
                break;
            }
            case 3:
            {
                System.out.println("\nYou Selected FrozenYogurt Category\n"); 
                break;
            }
            default:
            {
                
            }
        }
      }
        ing.toString();

  }
  
  
  
  
   public void SelectFlavour(int Choice44)
  {
        System.out.println("\nSelect Flavour\n1: Strawberry\n2: Chocolate\n3: Vanilla\n4: Coffee\n5: Cherry\n");
        Scanner ss=new Scanner(System.in);
        Choice=Choice44;
        
         switch(Choice-1)
         {
            case 0:
            {
                fla.display();
                fla=new Strawberry("pink", (float) 25.43);                
                fla.display();
                break;
            }
            case 1:
            {
                fla.display();
                fla=new Chocolate("Brown", (float) 17.33);                
                fla.display();
                break;
            }
            case 2:
            {
                fla.display();
                fla=new Vanilla("White", (float) 26.22);                
                fla.display();
                break;
            }
            case 3:
            {
                fla.display();
                fla=new Coffee("Dark Black", (float) 34.69);
                fla.display();
                break;
            }
            case 4:
            {
                fla.display();
                fla=new Cherry("Red", (float) 22.14);
                fla.display();
                break;
            }
            default:
              {
                 System.out.println("\nYou Selected an invalid option\n\n\tTRY AGAIN \n");
              }
         } 
  
       
  
  }
   
 
   
   
   
   public void SelctCategory(int Choice44)
   {
        System.out.println("\nSelect Category\n1: IceCream\n2: Gelato\n3: FrozenYogurt\n");
        Scanner se=new Scanner(System.in);
        Choice2=Choice44;
        
        switch(Choice2-1)
        {
            case 0:
            {
                cat.display();
                cat=new IceCream((float)13.5);
                cat.display();
                break;
            }
            case 1:
            {
                cat.display();                
                cat=new Gelato((float)18.2);
                cat.display();
                break;
            }
            case 2:
            {
                cat.display();                
                cat=new FrozenYogurt((float)15.7);
                cat.display();
                break;
            }
            default:
              {
                  System.out.println("\nYou Selected an invalid option\n\n\tTRY AGAIN \n");
              }
        } 
   }
   
  
   
    public void search()
    {
     System.out.println("\nPress 1 for Search a ingredients \nPress 2 for search a Worker:\n");
     Scanner scan=new Scanner(System.in);
     int choice3=scan.nextInt();
      if(choice3==1)
      {
        System.out.println("\nPress 1 for the details of Cream\nPress 2 for the details of Milk\nPress 3 for the details of Sugar\nPress 4 for the details of Vanilla\nPress 5 for the details of Condened Milk\n");
        Scanner n = new Scanner (System.in);
        int n2=n.nextInt();
                switch(n2)
                {
                     case 1:
                     {
                      System.out.println(ing.getC().dislplay());
                      break;
                     }
                     case 2:
                     {
                      System.out.println(ing.getM().dislplay());                         
                      break;
                     }
                     case 3:
                     {
                      System.out.println(ing.getS().dislplay());
                      break;
                     }
                     case 4:
                     {
                      System.out.println(ing.getV().dislplay());
                      break;                         
                     }
                     case 5:
                     {
                      System.out.println(ing.getCm().dislplay());
                      break;                         
                     }
                           default:
                           {
                            System.out.println("/nYou selected an invalid option/n");                     
                           }
                }
        
      }
        else if(choice3==2)
        {
            int i;
         System.out.println("\nEnter the name of a worker :\n");
         Scanner n = new Scanner (System.in);
         String n2=n.nextLine();
             for( i=0;i<w.size();i++) 
             {
                 if(w.get(i).getName().toLowerCase().contains(n2))
                  {
                   System.out.println(w.get(i).toString());                   
                   if(w.get(i).getName().toLowerCase().contains(n2))
                     {
                      w.get(i).check(i);
                     }
                  }
             } 
            
        }
          else
          {
           System.out.println("\nyou selct an invalid option\nTry Again\n");
          }
  }
   
    
    
     public int addPrice()
     {
         int f6 = 0;
         for(int i=Choice2;i<Choice2+1;i++)
         {
         float f1,f2,f3;
         f1=ing.TotalPrice();
         f2=fla.getPrice();
         f3=cat.categoryPrice(i);
         f6=(int) (f1+f2+f3);
         System.out.println("\nTotal price is "+f6);
         }     
         return f6;
     }


     
float v1,v2,v3,v4,v5;
public void RemainingIngredients()
{
  v1=ing.RemainCream();
  v2=ing.RemainMilk();
  v3=ing.RemainSugar();
  v4=ing.RemainVanila();
  v5=ing.RemainCondensedMilk();

  
    ing.getC().setamount(v1);
    ing.getM().setamount(v2);
    ing.getS().setamount(v3);
    ing.getV().setamount(v4);
    ing.getCm().setamount(v5);
    
}

public void RemainingIng2()
{
    System.out.println("\nRemainig Ingredients List:\n\nRemaining Cream =\t"+v1+" KGs");
    System.out.println("\nRemaining Milk =\t"+v2+" KGs");
    System.out.println("\nRemaining suagar =\t"+v3+" KGs");
    System.out.println("\nRemaining Vanila =\t"+v4+" KGs");
    System.out.println("\nRemaining condensedMilk =\t"+v5+" KGs");
} 




public void SameIngredients()
{
ing.display();
}


}