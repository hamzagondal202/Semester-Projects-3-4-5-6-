package finalprojecticecreamshop;

import java.util.ArrayList;


public class Ingredients 
{
private String CompanyName;
private Cream c;
private Milk m;
private Vanila v;
private Sugar s;
private CondensedMilk cm;

    public Ingredients(String CompanyName) 
    {
        this.CompanyName = CompanyName;
    }


    public Ingredients() 
    {
        c=new Cream();
        m=new Milk();   
        v=new Vanila();
        s=new Sugar();
        cm=new CondensedMilk();
    
    
    }



    public String getCompanyName() {
        return CompanyName;
    }

    public void setCompanyName(String CompanyName) {
        this.CompanyName = CompanyName;
    }

    


    public Milk getM() {
        return m;
    }

  

    public Vanila getV() {
        return v;
    }

    public Sugar getS() {
        return s;
    }


    public CondensedMilk getCm() {
        return cm;
    }

    public Cream getC() {
        return c;
    }



    public void addMilk(Milk mi)
    {
    this.m=mi;
    }
    
    public void addCream(Cream mk)
    {
     this.c=mk;
    }
    public void addSugar(Sugar mc)
    {
     this.s=mc;
    }
    public void addVanila(Vanila mv)
    {
     this.v=mv;
    }
    public void addCondensedMilk(CondensedMilk mcm)
    {
     this.cm=mcm;   
    }
    
    

public void display()
 {
            System.out.println("Ingredients{" + "CompanyName=" + CompanyName + ", c=" + c.dislplay() + ", m=" + m.dislplay() + ", v=" + v.dislplay() + ", s=" + s.dislplay() + ", cm=" + cm.dislplay() + '}');

 }

    @Override
    public String toString() {
        return "Ingredients{" + "CompanyName=" + CompanyName + ", c=" + c.toString() + ", m=" + m.toString() + ", v=" + v.toString() + ", s=" + s.toString() + ", cm=" + cm.toString() + '}';
    }


public float TotalPrice()
{
    float F;
    F=c.getPrice()+m.getPrice()+s.getPrice()+v.getPrice()+cm.getPrice();
    return F;
}






public float RemainCream()
{
    //It means that every order will deduct a certain quantity from Cream
    float X1;
    X1=(float) (c.getamount()-0.37);
    return X1;
}

public float RemainMilk()
{
    //It means that every order will deduct a certain quantity from Milk
    float X2;
    X2=(float) (m.getamount()-0.27);
    return X2;
}
public float RemainSugar()
{
    //It means that every order will deduct a certain quantity from Sugar
    float X3;
    X3=(float) (s.getamount()-0.40);
    return X3;
}
public float RemainVanila()
{
    //It means that every order will deduct a certain quantity from Vanila
    float X4;
    X4=(float) (v.getamount()-0.15);
    return X4;
}
public float RemainCondensedMilk()
{
    //It means that every order will deduct a certain quantity from CondensedMilk
    float X5;
    X5=(float) (cm.getamount()-0.19);
    return X5;
}


}
