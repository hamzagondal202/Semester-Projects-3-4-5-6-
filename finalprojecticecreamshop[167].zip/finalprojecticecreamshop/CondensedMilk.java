package finalprojecticecreamshop;

public class CondensedMilk 
{
  private float amount;
    private float Price;

    public CondensedMilk(float amount, float Price) {
        this.amount = amount;
        this.Price = Price;
    }

    public CondensedMilk() 
    {
        
    }

    public float getamount() {
        return amount;
    }

    public void setamount(float amount) {
        this.amount = amount;
    }

    public float getPrice() {
        return Price;
    }

    public void setPrice(float Price) {
        this.Price = Price;
    }

    
    
public float dislplay()
 {
 return amount;
 }

    @Override
    public String toString() {
        return "CondensedMilk{" + " Price=" + Price + '}';
    }


}
