package finalprojecticecreamshop;


public class CounterBoy extends Worker
{
 private int id;

    public CounterBoy() 
    {
        
    }

    public CounterBoy(int id) 
    {
        
        this.id = id;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



 @Override
 public void display()
  {
  System.out.println("\nWorker is CounterBoy and it's ID is :\t"+id);
  }

    @Override
    public String toString() {
        return "CounterBoy{" + "id=" + id + '}';
    }
    
    
}
