package finalprojecticecreamshop;


public class Worker 
{
protected String name,address;
    public Worker() 
    {
        
    }

    public Worker(String name, String address) 
    {
        this.name = name;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void check(int s)
    {
        if(s<1)
        {
         sheff c=new sheff(19670);
         c.display();
        }
        else if(s<2)
        {
         CounterBoy cb=new CounterBoy(24471);
         cb.display();
        }
        else if(s<3)
        {
         CounterBoy cd=new CounterBoy(23476);
        cd.display();
        }
        else
        {
        
        }
    }
    
    
    

public void  display()
  {
  System.out.println("\nName of a worker is :\t"+name+"\nAddress of a worker is :\t"+address);
  }

    @Override
    public String toString() 
    {
        return "Worker{" + "name=" + name + ", address=" + address + '}';
    }

}
