package finalprojecticecreamshop;


public class Category 
{
private float Density,Viscosity,Fat;
private Category ca;
    public Category() 
    {    
    }

    public Category(float Density, float Viscosity, float Fat)
    {
        this.Density = Density;
        this.Viscosity = Viscosity;
        this.Fat = Fat;
    }

   
    public float getDenisty() {
        return Density;
    }

    public void setDenisty(float Denisty) {
        this.Density = Denisty;
    }

    public float getViscosity() {
        return Viscosity;
    }

    public void setViscosity(float Viscosity) {
        this.Viscosity = Viscosity;
    }

    public float getFat() {
        return Fat;
    }

    public void setFat(float Fat) {
        this.Fat = Fat;
    }
    


    public float categoryPrice(int i)
  {   
        if(i<2)
        {
         ca=new IceCream((float) 13.5);
        }
       else if(i<3)
        {
         ca=new Gelato((float)18.2);
        } 
       else 
        {
         ca=new FrozenYogurt((float)15.7);
        }
                float f4;
                f4=ca.ring();
          return f4;

  }
    
    
    
    
    
    
    public void display()
      {
      System.out.println("Density of aCategory is : "+Density+"\nViscosity of a Category is : "+Viscosity+"\nFat of a Category is : "+Fat);        
      }

    @Override
    public String toString() 
    {
        return "Category{" + "Density=" + Density + ", Viscosity=" + Viscosity + ", Fat=" + Fat + '}';
    }
     
    public float ring() 
    {
        return +Density+Viscosity+Fat;
    }
}
