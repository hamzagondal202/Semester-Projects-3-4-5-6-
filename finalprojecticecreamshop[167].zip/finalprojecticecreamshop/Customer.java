package finalprojecticecreamshop;

import java.util.Scanner;


public class Customer 
{
private String Name;

    public String getName() 
    {
        return Name;
    }

    public void setName() 
    {
    Scanner sw=new Scanner(System.in);    
    System.out.println("Enter your Full name : ");
    Name=sw.nextLine();
    }
   public void setName(String name) 
    {
    this.Name=name;
    }


public void display()
  {
System.out.println("\n\nName of a Customer is :\t"+Name);
  }



}
