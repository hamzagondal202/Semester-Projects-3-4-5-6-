
package finalprojecticecreamshop;


public class sheff extends Worker
{
    private int id;

    public sheff() 
    {
        
    }

    public sheff(int id) 
    {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    @Override
    public void display()
  {
    System.out.println("\nWorker is Sheff and it's ID is :\t"+id);
  }

    @Override
    public String toString() {
        return "sheff{" + "id=" + id + '}';
    }
    
    
    
}
