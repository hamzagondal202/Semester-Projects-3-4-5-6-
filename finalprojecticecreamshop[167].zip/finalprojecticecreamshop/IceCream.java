package finalprojecticecreamshop;


public class IceCream extends Category
{
private float price;


    public IceCream() 
    {
        
    }

    public IceCream(float price) 
    {
        this.price = price;
    }

    

    public float getPrice() 
    {
        return price;
    }

  
    
    
    
@Override
public void display()
  {
  System.out.println("Price of a category is : "+price);
  }

    
@Override
    public float ring() {
        return price;
    }

  
    
    
    
}