package finalprojecticecreamshop;


public class Gelato extends Category
{
private float price;


    public Gelato() 
    {
        
    }

    public Gelato(float price) 
    {
        this.price = price;
    }

    

    public float getPrice() 
    {
        return price;
    }

   




@Override
public void display()
  {
  System.out.println("Price of a category is : "+price);
  }

@Override
    public float ring() 
    {
        return price;
    }



    
    
}
