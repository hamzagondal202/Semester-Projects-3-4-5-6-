package finalprojecticecreamshop;

import java.util.Scanner;


public class Finalprojecticecreamshop 
{
    public static void main(String[] args) 
    {
       // GUI g=new GUI();
        //g.show();
        
        Ingredients ii=new Ingredients();
        ii.setCompanyName("Nestle");

        
        Milk m1=new Milk((float) 100.60, (float) 13.50);
        Cream c1=new Cream((float) 153.90, (float) 20.9);
        Sugar s1=new Sugar((float) 200.00, (float) 15.4);
        Vanila v1=new Vanila((float) 80.20, (float) 19.2);
        CondensedMilk cm1=new CondensedMilk((float) 70.70, (float) 10.6);
 
        
        
       //adding milk cream etc in Ingredients class
 
        ii.addMilk(m1);
        ii.addCream(c1);
        ii.addSugar(s1);
        ii.addVanila(v1); 
        ii.addCondensedMilk(cm1);
        
        
        //adding all ingredients in Icecreamshop
        IceCreamShop ics=new IceCreamShop();
        ics.addIngredients(ii);
        
        
        
         //Adding Flavour in Icecream Shop     
        Flavour fl=new Flavour((float) 20.5);  
          ics.addFlavour(fl);
          
          
          
         //Adding Category in Icecream Shop
          Category ct=new Category((float) 20.9,(float)24.9,(float)15.2);
          ics.addCategory(ct);
          
          
        //Adding workers in Icecreamshop  
        Worker w1=new Worker("Ahmed Ali"," Block#2 ; Flat#3 ; G-8/4 ; street#5 ;Islamabad");    
        ics.addWorker(w1);

        Worker w2=new Worker("Kamran yousaf","House#103 ; street#44 ; Shamsabad ; Rawalpindi");
        ics.addWorker(w2);
        
        Worker w3=new Worker("Ihtesham ul hassan","E-11/3 ; Bahria town ; Street#13 ;  ; ISlamabad");
        ics.addWorker(w3);
        
        
        
        System.out.println("1:\tBuy Movie\n2:\tAdmin Login");
        Scanner bm=new Scanner(System.in);
        int cho=bm.nextInt();
        if(cho==1)
        {
        //Gettting Customer Data
          ics.Customer();
        
        //cutsomer have to select Flavour
         // ics.SelectFlavour();
        
        //cutsomer have to select Category
          //ics.SelctCategory();
   
        //Display all the detail of order
          ics.OrderDetail();
        
        //totalprice         
          ics.addPrice();          
       
        }
        else if (cho==2)
           {
            System.out.println("Enter Admin Id:\t\n");
            Scanner xr=new Scanner(System.in);
            int Choice=xr.nextInt();
              if(Choice==8566166)
              {     
              //search workers or ingredients 
                ics.search();
                System.out.println("\nDo you want to Search Remaining ingredients\n1:\tYes\n2:\tNo\n");
                Scanner x=new Scanner(System.in);
                int Choi=x.nextInt();
                  if(Choi==1)
                  {                      
                      System.out.println("how many Ice Creams have been ordered");
                      Scanner x2=new Scanner(System.in);
                      int Cj=x2.nextInt();
                    {
                      for(int c=0;c<Cj;c++)
                     {
                       //Remaining Ingredients quantity in IceCreamChop
                         ics.RemainingIngredients();
                     }
                      ics.RemainingIng2();
                    }
                        if(Cj==0)
                         {
                          ics.SameIngredients();
                         }
                          else
                           {
                       
                           }
                     
                  }
                  else if(Choi==2)
                  {
                   
                  }
                  else
                  {
                  System.out.println("You selected an invalid option");
                  }
              }
              else
              {
              System.out.println("\n\tWrong ID\n\t\tTry Again\n\t\t\t\tThank You");
              }
           }
        else
        {
        System.out.println("You selected an invalid option\n\t\tTry Again\n\t\t\t\tThank  You\n");
        }
                  
    }
    
}
