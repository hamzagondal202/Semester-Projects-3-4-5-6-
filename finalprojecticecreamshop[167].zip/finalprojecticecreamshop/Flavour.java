package finalprojecticecreamshop;

public class Flavour 
{
 private float Price;

    public Flavour() 
    {
        
    }

    public Flavour(float Price) {
        this.Price = Price;
    }

    public float getPrice() {
        return Price;
    }

    public void setPrice(float Price) {
        this.Price = Price;
    }
 

 public void display()
   {
    System.out.println("Price of a flavour is :"+Price);
   }
    
}
