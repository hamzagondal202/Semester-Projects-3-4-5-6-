
package finalprojecticecreamshop;

public class Sugar 
{
  private float amount;
    private float Price;

    public Sugar(float amount, float Price) {
        this.amount = amount;
        this.Price = Price;
    }

    public Sugar() 
    {
        
    }

    
    public float getamount() {
        return amount;
    }

    public void setamount(float amount) {
        this.amount = amount;
    }

    public float getPrice() {
        return Price;
    }

    public void setPrice(float Price) {
        this.Price = Price;
    }

    
    
public float dislplay()
 {
 return amount;
 }   

    @Override
    public String toString() {
        return "Sugar{" + " Price=" + Price + '}';
    }


}
