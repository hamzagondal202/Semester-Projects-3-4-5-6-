<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sahil";

// Create connection
$conn = new mysqli($servername,
	$username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
	die("Connection failed: "
		. $conn->connect_error);
}

$msg = $_GET["msg"]

$sqlquery = "INSERT INTO Message VALUES
	('$msg')"

if ($conn->query($sql) === TRUE) {
	echo "record inserted successfully";
} else {
	echo "Error: " . $sql . "<br>" . $conn->error;
}
